﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Estructura_de_datos
{
    public class EmpleadoCola
    {
        //Propiedades para la cola
        public string Identificacion { get; set; }
        public string Nombre { get; set; }
        public Decimal Salaio { get; set; }
        public DateTime Fecha { get; set; }
    }
}
